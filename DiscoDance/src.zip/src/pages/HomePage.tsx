import Menu from "../components/Menu";

const HomePage = () => {
    return (
        <div>
            <Menu />
        </div>
    );
};

export default HomePage;
