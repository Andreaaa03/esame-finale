import { LoginLogout } from "../components/LoginLogout";

const AccediRegistrati=()=>{
    return(
        <div className="flex w-full min-h-screen justify-center items-center    ">
            <LoginLogout/>
        </div>
    );
}

export default AccediRegistrati;